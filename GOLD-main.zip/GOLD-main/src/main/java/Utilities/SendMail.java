package Utilities;


public class SendMail {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		

		StatusMail.sendMail();
		
		//System.out.println("Revlon.ST_Register".split("\\.")[0]);

	}

}
