package TestLib;

import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.config.ConfigurationFactory;

import Utilities.log4j;

public class Driver {
	 final public static log4j logger = new log4j();
	
	
	public static log4j getLogger() {	
		return logger;
	}
	
	
	
	

	

}
