# GOLD
Automation scripts for Gold project
